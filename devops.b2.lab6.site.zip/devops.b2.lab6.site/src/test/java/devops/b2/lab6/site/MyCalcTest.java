package devops.b2.lab6.site;

import static org.junit.Assert.*;

import org.junit.Test;

import pkg1.MyCalc;

public class MyCalcTest {

	@Test
	public void test() {		
		MyCalc ob = new MyCalc();
		assertEquals(5, ob.sum(2, 3));
		assertEquals(6, ob.mul(2, 3));
	}

}
