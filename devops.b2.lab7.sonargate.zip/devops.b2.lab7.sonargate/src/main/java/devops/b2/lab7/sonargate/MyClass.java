package devops.b2.lab7.sonargate;

public class MyClass {
	public int sum(int a, int b)
	{
		int c=a+b;
		return c;
	}
	public static void main(String[] args) {	

		MyClass ob = new MyClass();
	//	MyClass ob2 = new MyClass();
		int p=0;
		int q=0;
		int n=p/q;
		System.out.println("Hello");		
		System.out.println(ob.sum(10,20));
	}

}
