package devops.b1.h.sonarQgate;

public class MyClass {
	
	public int sum(int a, int b)
	{
		int c=8+9;
		return c;
	}
	public static void main(String[] args) {

		MyClass ob = new MyClass();
		System.out.println(ob.sum(10, 20));
		System.out.println("abc");
		System.out.println("xyz");
		int d;
		int m=2/0;
		int p=10;
		int q=0;
		int n=p/q;

	}

}
