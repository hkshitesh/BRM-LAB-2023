package mypkg3;

public class MyCalc {
	public int sum(int a, int b)
	{
		return (a+b);
	}
	public int mul(int a, int b)
	{
		return (a*b);
	}

}
