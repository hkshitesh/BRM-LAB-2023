package devops.b1.h.lab6.site;

import static org.junit.Assert.*;

import org.junit.Test;

import pkg1.MyCalc;

public class MyCalcTest {

	@Test
	public void test() {

		MyCalc ob = new MyCalc();
		assertEquals(10, ob.sum(4, 6));
		assertEquals(24, ob.mul(4, 6));
		
	}

}
