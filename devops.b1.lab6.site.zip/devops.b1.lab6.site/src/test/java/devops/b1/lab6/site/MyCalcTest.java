package devops.b1.lab6.site;

import static org.junit.Assert.*;

import org.junit.Test;

public class MyCalcTest {

	@Test
	public void test() {
		
		MyCalc ob = new MyCalc();
		assertEquals(30, ob.sum(10, 20));
		
	}
}
