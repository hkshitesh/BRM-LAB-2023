package devops.b1.lab6.site;

public class MyCalc {
	public int sum(int a, int b)
	{
		return(a+b);
	}

	public static void main(String[] args) {
		
  MyCalc ob = new MyCalc();
  System.out.println(ob.sum(10, 20));
	}

}
