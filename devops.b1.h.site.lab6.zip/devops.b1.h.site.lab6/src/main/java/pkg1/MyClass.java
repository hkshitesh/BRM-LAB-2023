package pkg1;
public class MyClass 
{	
	public int findAverage(int a, int b, int c)
	{
		int d;
		int avg=(a+b+c)/3;
		return avg;
	}
}