package devops.b1.h.site.lab6;
import static org.junit.Assert.*;

import org.junit.Test;

import pkg1.MyClass;

public class MyClassTest {

	@Test
	public void test() {

		MyClass ob = new MyClass();
		assertEquals(3, ob.findAverage(2, 3, 4));
	}
}