package pkg1;

public class MyClass2 {
	public int sum2(int a, int b)
	{
		int c=3+5
		int d
		return c;
	}

	public static void main(String[] args) {
		MyCalc1 ob = new MyCalc1()

	}

}
